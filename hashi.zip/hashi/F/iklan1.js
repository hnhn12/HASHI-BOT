const iklan1 = () => {
	return`[ MASUKIN IKLAN KALIAN ]`
}

exports.iklan1 = iklan1