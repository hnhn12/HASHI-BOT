const iklan2 = () => {
	return`[ MASUKIN IKLAN KALIAN ]`
}

exports.iklan2 = iklan2